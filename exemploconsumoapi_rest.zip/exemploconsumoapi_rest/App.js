import { StyleSheet, Text, View, TouchableOpacity } from 'react-native';
import { useState } from 'react';
import axios from 'axios';

export default function App() {
  const [conselho, setConselho] = useState('Espaço para a frase (em inglês)');

  function buscarConselhoThen() {
    fetch('https://dummyjson.com/quotes/random')
      .then(response => response.json())
      .then(res => setConselho(`${res.quote} — ${res.author}`))
      .catch(error => console.error('Erro:', error));
  }

  async function buscarConselhoAsync() {
    try {
      const response = await fetch(
        'https://dummyjson.com/quotes/random'
      );

      const dados = await response.json();

      setConselho(`${dados.quote} — ${dados.author}`);

    } catch (erro) {
      console.error('Erro:', erro);
    }
  }

  async function buscarConselhoAxios() {
    try {
      const response = await axios.get(
        'https://dummyjson.com/quotes/random'
      );

      setConselho(`${response.data.quote} — ${response.data.author}`);

    } catch (erro) {
      console.error('Erro:', erro);
    }
  }

  return (
    <View style={styles.container}>
      <Text style={styles.marginBottom10}>{conselho}</Text>

      <TouchableOpacity style={styles.button} onPress={buscarConselhoAsync}>
        <Text style={styles.buttonText}>
            Buscar Frase
        </Text>
      </TouchableOpacity>

    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  button: {
    backgroundColor: 'blue',
    width: '50%',
    height: 30,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 8
  },
  buttonText: {
    color: 'white'
  },
  marginBottom10: {
    marginBottom: 10,
    textAlign: 'center',
    paddingHorizontal: 20
  }
});